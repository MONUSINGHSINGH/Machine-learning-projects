# Machine Learning Mini Projects
This repository contains mini projects in machine learning with jupyter notebook files.
Go to the projects folder and see the readme for detailed instructions about the projects.

# Complete video tutorial for the projects:-
https://www.youtube.com/playlist?list=PL_8jNcohs27W5mE5JPkWpvj8tVxu6Atfo
